package com.lastwave.app.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState as PlatformPlaybackState
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.support.v4.media.MediaBrowserCompat
import android.support.v4.media.MediaDescriptionCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.RatingCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.view.View
import android.widget.RemoteViews
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.toBitmap
import androidx.media.MediaBrowserServiceCompat
import androidx.media.VolumeProviderCompat
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.lastwave.app.MainActivity
import com.lastwave.app.R
import com.lastwave.app.data.local.ScrobblerPreferences
import com.lastwave.app.data.local.ScrobblerSettings
import com.lastwave.app.data.playlist.TrackLikeController
import com.lastwave.app.data.repository.ScrobbleRepository
import com.lastwave.app.data.repository.ThemeRepository
import com.lastwave.app.playback.resolve.MetadataLog

import com.lastwave.app.widget.ActiveMediaSessionHolder
import com.lastwave.app.widget.WidgetUpdater
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

private val TOPIC_SUFFIX_REGEX = Regex("""(?i)\s*-\s*topic$""")
private val VEVO_SUFFIX_REGEX = Regex("""(?i)\s*vevo$""")
private val TITLE_SUFFIX_REGEX = Regex(
    """(?i)\s*[\(\[](official\s*(music\s*)?video|official\s*audio|visualizer|audio|lyric\s*video|lyrics|hd|4k|remastered|hq)[\)\]]""",
)

private data class CleanTrackMetadata(val title: String, val artist: String)

private fun sameServiceState(previous: MusicPlayerState, current: MusicPlayerState): Boolean =
    previous.current == current.current &&
        previous.queue == current.queue &&
        previous.currentIndex == current.currentIndex &&
        previous.isPlaying == current.isPlaying &&
        previous.isBuffering == current.isBuffering &&
        previous.durationMs == current.durationMs &&
        previous.speed == current.speed &&
        previous.shuffleEnabled == current.shuffleEnabled &&
        previous.repeatMode == current.repeatMode &&
        previous.isCasting == current.isCasting &&
        previous.appVolume == current.appVolume &&
        (previous.isPlaying || current.isPlaying || previous.positionMs == current.positionMs)

/**
 * Foreground playback host and standard Android MediaSession bridge. It
 * gives the singleton player lock-screen, notification, headset, Bluetooth
 * and external hardware controls without requiring notification-listener
 * access.
 */
@AndroidEntryPoint
class MusicPlaybackService : MediaBrowserServiceCompat() {
    @Inject lateinit var musicPlayer: MusicPlayer
    @Inject lateinit var scrobbleRepository: ScrobbleRepository
    @Inject lateinit var scrobblerPreferences: ScrobblerPreferences

    @Inject lateinit var themeRepository: ThemeRepository
    @Inject lateinit var artworkRepository: com.lastwave.app.data.artwork.ArtworkRepository
    @Inject lateinit var androidAutoLibrary: AndroidAutoMediaLibrary
    @Inject lateinit var trackLikeController: TrackLikeController
    @Inject lateinit var jamPlaybackSync: com.lastwave.app.playback.jam.JamPlaybackSync

    // SupervisorJob stops sibling failure propagation; the handler below
    // additionally stops an unexpected exception in any fire-and-forget
    // launch (scrobble, artwork, notification publish) from reaching the
    // default handler and killing the whole process mid-playback. These are
    // swallowed on purpose — but they still reach the on-disk log, so a
    // repeatedly failing subsystem is visible instead of invisible.
    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main.immediate +
            CoroutineExceptionHandler { _, error ->
                com.lastwave.app.diagnostics.AppLog.e(
                    "MusicPlaybackService",
                    "Suppressed playback service coroutine failure",
                    error,
                )
            },
    )
    // A handful of ROMs ship broken or deliberately crippled media-session
    // stacks where constructing a MediaSession or MediaController throws, or
    // the binder calls fail at runtime. Audio playback itself never depends
    // on either handle, so they stay nullable and every use degrades to
    // notification-only transport controls instead of crashing the service.
    private var mediaSession: MediaSessionCompat? = null
    private var platformSessionToken: MediaSession.Token? = null
    private var ownController: MediaController? = null
    private var settings = ScrobblerSettings()
    private var detectorJob: Job? = null
    private var detectedKey = ""
    private var nowPlayingAnnouncedKey = ""
    @Volatile private var nowPlayingInFlight = false
    private var accumulatedMs = 0L
    private var lastPositionMs = 0L
    private var startedAtEpochSec = 0L
    private var submissionAttempted = false
    private var retryCount = 0
    private var pendingPreviousTrack: PlayableTrack? = null
    private var pendingPreviousStartedAt: Long = 0L
    private var cleanedSourceTitle = ""
    private var cleanedSourceArtist = ""
    private var cleanedMetadata = CleanTrackMetadata("", "")
    private var artworkJob: Job? = null
    private var artworkUrl: String? = null
    private var artworkBitmap: Bitmap? = null
    private var notificationSignature = ""
    private var widgetSignature = ""
    private var systemStateSignature = ""
    private var legacyBroadcastSignature = ""
    private var sessionQueueSignature = ""
    private var carBrowseQueueSignature = ""
    @Volatile private var isPlaybackForeground = false
    private var artworkRequestKey = ""
    private var notificationPalette = NotificationPalette.default()
    private var playbackWakeLock: PowerManager.WakeLock? = null
    private var playbackWifiLock: WifiManager.WifiLock? = null

    override fun onCreate() {
        super.onCreate()
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        playbackWakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "LastWave:PlaybackWakeLock",
        )?.apply { setReferenceCounted(false) }

        val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        playbackWifiLock = wifiManager?.createWifiLock(
            WifiManager.WIFI_MODE_FULL_HIGH_PERF,
            "LastWave:PlaybackWifiLock",
        )?.apply { setReferenceCounted(false) }

        createNotificationChannel()
        runCatching {
            val session = MediaSessionCompat(this, "LastWavePlayer").apply {
                setFlags(
                    MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                        MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS,
                )
                setPlaybackToLocal(android.media.AudioManager.STREAM_MUSIC)
                setCallback(object : MediaSessionCompat.Callback() {
                    override fun onPlay() = musicPlayer.resume()
                    override fun onPause() = musicPlayer.pause()
                    override fun onSkipToNext() = musicPlayer.next()
                    override fun onSkipToPrevious() = musicPlayer.previous()
                    override fun onSeekTo(pos: Long) = musicPlayer.seekTo(pos)
                    // A stop from an external controller (Bluetooth/car unit,
                    // OEM media card, system UI) ends playback but must not
                    // destroy the session. Wiping the queue, the persisted
                    // session and the notification here turned a routine focus
                    // hand-off — another app taking over the media card, which
                    // some OEM skins report as a stop — into "the song
                    // disappears and I have to reopen the app". The
                    // notification's own Stop action and ACTION_STOP still do
                    // the destructive stop.
                    override fun onStop() = musicPlayer.pause()
                    override fun onSkipToQueueItem(id: Long) = musicPlayer.seekToQueueItem(id.toInt())
                    override fun onSetShuffleMode(shuffleMode: Int) {
                        musicPlayer.setShuffleEnabled(shuffleMode != PlaybackStateCompat.SHUFFLE_MODE_NONE)
                    }
                    override fun onSetRepeatMode(repeatMode: Int) {
                        musicPlayer.setRepeatMode(
                            when (repeatMode) {
                                PlaybackStateCompat.REPEAT_MODE_ONE -> androidx.media3.common.Player.REPEAT_MODE_ONE
                                PlaybackStateCompat.REPEAT_MODE_ALL,
                                PlaybackStateCompat.REPEAT_MODE_GROUP -> androidx.media3.common.Player.REPEAT_MODE_ALL
                                else -> androidx.media3.common.Player.REPEAT_MODE_OFF
                            },
                        )
                    }
                    override fun onPlayFromMediaId(mediaId: String?, extras: Bundle?) {
                        if (mediaId == OriginOsMusicCard.EMPTY_LIST_MEDIA_ID) return
                        mediaId?.let { playCarMediaId(OriginOsMusicCard.queueMediaIdOf(it)) }
                    }
                    override fun onSetRating(rating: RatingCompat?) {
                        if (rating?.ratingStyle == RatingCompat.RATING_HEART) setCurrentTrackLiked(rating.hasHeart())
                    }
                    override fun onCustomAction(action: String?, extras: Bundle?) {
                        if (action == OriginOsMusicCard.ACTION_PLAY_MODE) {
                            setOriginOsLoopMode(extras?.getInt(OriginOsMusicCard.KEY_LOOP_MODE) ?: 0)
                        }
                    }
                    override fun onPlayFromSearch(query: String?, extras: Bundle?) {
                        playCarSearch(resolveCarSearchQuery(query, extras))
                    }
                })
                setSessionActivity(openAppPendingIntent())
                // The heart of external controllers, such as the OriginOS music card.
                setRatingType(RatingCompat.RATING_HEART)
                // KWGT / Bluetooth / headset discovery happens while idle too:
                // publish an initial state so media buttons (and widget play
                // buttons) can wake the player before any track is queued.
                setPlaybackState(
                    PlaybackStateCompat.Builder()
                        .setActions(
                            PlaybackStateCompat.ACTION_PLAY or
                                PlaybackStateCompat.ACTION_PLAY_PAUSE or
                                PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID or
                                PlaybackStateCompat.ACTION_PLAY_FROM_SEARCH,
                        )
                        .setState(PlaybackStateCompat.STATE_NONE, 0, 0f)
                        .build(),
                )
                isActive = true
            }
            mediaSession = session
            sessionToken = session.sessionToken
            platformSessionToken = session.sessionToken.token as? MediaSession.Token
            ownController = platformSessionToken?.let { token -> MediaController(this, token) }
            ActiveMediaSessionHolder.ownToken = platformSessionToken
        }.onFailure { error ->
            android.util.Log.e("MusicPlaybackService", "System media integration unavailable; continuing audio-only", error)
            runCatching { mediaSession?.release() }
            mediaSession = null
            platformSessionToken = null
            ownController = null
            ActiveMediaSessionHolder.ownToken = null
        }
        notificationPalette = NotificationPalette.from(themeRepository.uiState.value.colorScheme)
        scope.launch { scrobblerPreferences.settings.collect { settings = it } }
        scope.launch {
            themeRepository.uiState.collectLatest { theme ->
                val newPalette = NotificationPalette.from(theme.colorScheme)
                // Only force a notification rebuild when the palette actually
                // changed — unrelated DataStore settings also flow through this
                // state and used to trigger pointless RemoteViews rebuilds.
                if (newPalette != notificationPalette) {
                    notificationPalette = newPalette
                    notificationSignature = ""
                    publishNotification(musicPlayer.state.value, force = true)
                }
            }
        }
        scope.launch {
            musicPlayer.state
                // Position/buffer ticks arrive about 16 times per second for
                // the seek bar. Notification, widget and MediaSession chrome
                // do not need that cadence; Android extrapolates a playing
                // position from the published speed. Filter those ticks before
                // doing string work, artwork lookup and binder-state checks.
                .distinctUntilChanged(::sameServiceState)
                .collect { state ->
                    updateWakeLocks(state)
                    requestArtwork(state.current)
                    publishSystemState(state)
                    publishNotification(state)
                    publishWidget(state)
                    publishCarBrowseState(state)
                    detectTransition(state)
                    themeRepository.updateNowPlayingArtwork(state.current?.title, state.current?.artist)
                }
        }
        scope.launch {
            artworkRepository.resolved.collect { map ->
                val current = musicPlayer.state.value.current ?: return@collect
                val key = com.lastwave.app.data.artwork.ArtworkNormalizer.cacheKey(current.title, current.artist)
                val resolvedUrl = map[key]
                if (!resolvedUrl.isNullOrBlank() && resolvedUrl != artworkUrl) {
                    fetchArtwork(resolvedUrl)
                    if (musicPlayer.state.value.isPlaying) {
                    }
                }
            }
        }
        scope.launch {
            androidAutoLibrary.playlistChanges.collect {
                notifyCarLibraryChanged(AndroidAutoMediaLibrary.PLAYLISTS_ID)
                notifyChildrenChangedSafely(OriginOsMusicCard.LIST_FAVORITE)
            }
        }
        scope.launch {
            androidAutoLibrary.downloadChanges.distinctUntilChanged().collect {
                notifyCarLibraryChanged(AndroidAutoMediaLibrary.DOWNLOADS_ID)
                notifyChildrenChangedSafely(OriginOsMusicCard.LIST_LOCAL)
            }
        }
        scope.launch {
            // The heart of the metadata follows a like made anywhere in the app.
            trackLikeController.likedTrackKeys.drop(1).collect {
                publishSystemState(musicPlayer.state.value)
            }
        }
        startDetector()
    }

    override fun onGetRoot(
        clientPackageName: String,
        clientUid: Int,
        rootHints: Bundle?,
    ): BrowserRoot? {
        if (mediaSession == null) return null
        // KWGT, Wear OS, Bluetooth companions and other third-party
        // controllers connect here as ordinary user apps — NOT as system /
        // car hosts. Returning null rejects the connection
        // (onConnectionFailed), which is why KWGT never listed LastWave as
        // a media app and its transport buttons did nothing. The browse tree
        // only exposes queue/playlist/download metadata, so any
        // UID-verified caller may browse; transport stays gated by the
        // session callback itself.
        if (!isAllowedMediaClient(clientPackageName, clientUid)) return null
        return BrowserRoot(
            AndroidAutoMediaLibrary.ROOT_ID,
            Bundle().apply {
                putInt(CONTENT_STYLE_BROWSABLE_HINT, CONTENT_STYLE_LIST)
                putInt(CONTENT_STYLE_PLAYABLE_HINT, CONTENT_STYLE_LIST)
                putBoolean("android.media.browse.SEARCH_SUPPORTED", true)
            },
        )
    }

    override fun onLoadChildren(
        parentId: String,
        result: Result<List<MediaBrowserCompat.MediaItem>>,
    ) {
        result.detach()
        scope.launch {
            val children = runCatching {
                withContext(Dispatchers.IO) {
                    androidAutoLibrary.loadChildren(parentId, musicPlayer.state.value)
                }
            }.onFailure { error ->
                android.util.Log.w("MusicPlaybackService", "Android Auto browse failed for $parentId", error)
            }.getOrDefault(emptyList())
            result.sendResult(children)
        }
    }

    /**
     * The lists of the OriginOS music card: the queue, the playlists and the
     * downloads, all from the Android Auto browse tree. Everything else is
     * browsed as before.
     */
    override fun onLoadChildren(
        parentId: String,
        result: Result<List<MediaBrowserCompat.MediaItem>>,
        options: Bundle,
    ) {
        if (!OriginOsMusicCard.isList(parentId)) {
            super.onLoadChildren(parentId, result, options)
            return
        }
        result.detach()
        scope.launch {
            // Every list is a single page.
            val firstPage = options.getInt(OriginOsMusicCard.KEY_PAGE) == 0
            val children = if (!firstPage) emptyList() else runCatching {
                val state = musicPlayer.state.value
                when (parentId) {
                    OriginOsMusicCard.LIST_CURRENT -> state.queue.mapIndexed { index, track ->
                        MediaBrowserCompat.MediaItem(
                            MediaDescriptionCompat.Builder()
                                // Matches the media id of the metadata, so the card marks what plays.
                                .setMediaId(OriginOsMusicCard.mediaIdOf(index, track))
                                .setTitle(track.title)
                                .setSubtitle(track.artist)
                                .build(),
                            MediaBrowserCompat.MediaItem.FLAG_PLAYABLE,
                        )
                    }.let { OriginOsMusicCard.singlePage(it, "Nothing playing", "Play something in LastWave") }
                    OriginOsMusicCard.LIST_FAVORITE -> OriginOsMusicCard.singlePage(
                        withContext(Dispatchers.IO) {
                            androidAutoLibrary.loadChildren(AndroidAutoMediaLibrary.PLAYLISTS_ID, state)
                        },
                        "No playlists",
                        "Your playlists show here",
                    )
                    else -> OriginOsMusicCard.singlePage(
                        withContext(Dispatchers.IO) {
                            androidAutoLibrary.loadChildren(AndroidAutoMediaLibrary.DOWNLOADS_ID, state)
                        },
                        "No downloads",
                        "Music downloaded in LastWave shows here",
                    )
                }
            }.onFailure { error ->
                android.util.Log.w("MusicPlaybackService", "Music card list failed for $parentId", error)
            }.getOrDefault(emptyList())
            result.sendResult(children)
        }
    }

    private fun setCurrentTrackLiked(liked: Boolean) {
        val track = musicPlayer.state.value.current ?: return
        if (trackLikeController.isLiked(track) == liked) return
        scope.launch {
            runCatching { trackLikeController.toggle(track) }
                .onFailure { error -> android.util.Log.w("MusicPlaybackService", "Music card like failed", error) }
        }
    }

    private fun setOriginOsLoopMode(loopMode: Int) {
        val (shuffleEnabled, repeatMode) = OriginOsMusicCard.playModesOf(loopMode) ?: return
        musicPlayer.setShuffleEnabled(shuffleEnabled)
        musicPlayer.setRepeatMode(repeatMode)
    }

    private fun notifyChildrenChangedSafely(parentId: String) {
        runCatching { notifyChildrenChanged(parentId) }
    }

    override fun onSearch(
        query: String,
        extras: Bundle?,
        result: Result<List<MediaBrowserCompat.MediaItem>>,
    ) {
        result.detach()
        scope.launch {
            val items = runCatching {
                withContext(Dispatchers.IO) { androidAutoLibrary.search(query) }
            }.onFailure { error ->
                android.util.Log.w("MusicPlaybackService", "Android Auto search failed", error)
            }.getOrDefault(emptyList())
            result.sendResult(items)
        }
    }

    private fun isAllowedMediaClient(clientPackageName: String, clientUid: Int): Boolean = runCatching {
        // System_server sometimes proxies browse connections (notably some
        // Android Auto ROMs); always allow it.
        if (clientUid == android.os.Process.SYSTEM_UID || clientUid == android.os.Process.myUid()) return@runCatching true
        // Android Auto projection & automotive packages
        if (clientPackageName == "com.google.android.projection.gearhead" ||
            clientPackageName == "com.google.android.carprojection" ||
            clientPackageName == "com.google.android.apps.auto.repl" ||
            clientPackageName == "com.google.android.googlequicksearchbox"
        ) return@runCatching true
        val packages = packageManager.getPackagesForUid(clientUid)
        if (packages.isNullOrEmpty()) return@runCatching true
        packages.contains(clientPackageName)
    }.getOrDefault(true)

    private fun playCarMediaId(mediaId: String) {
        scope.launch {
            val played = runCatching {
                withContext(Dispatchers.IO) { androidAutoLibrary.playMediaId(mediaId, musicPlayer) }
            }.onFailure { error ->
                android.util.Log.w("MusicPlaybackService", "Android Auto playback request failed", error)
            }.getOrDefault(false)
            if (!played) publishCarPlaybackError("That item is no longer available")
        }
    }

    private fun playCarSearch(query: String) {
        if (query.isBlank()) {
            musicPlayer.resume()
            return
        }
        scope.launch {
            val played = runCatching {
                withContext(Dispatchers.IO) { androidAutoLibrary.playSearch(query, musicPlayer) }
            }.onFailure { error ->
                android.util.Log.w("MusicPlaybackService", "Android Auto voice search failed", error)
            }.getOrDefault(false)
            if (!played) publishCarPlaybackError("No playable tracks found")
        }
    }

    private fun resolveCarSearchQuery(query: String?, extras: Bundle?): String {
        query?.trim()?.takeIf(String::isNotEmpty)?.let { return it }
        return listOfNotNull(
            extras?.getString(MediaStore.EXTRA_MEDIA_TITLE),
            extras?.getString(MediaStore.EXTRA_MEDIA_ARTIST),
            extras?.getString(MediaStore.EXTRA_MEDIA_ALBUM),
        ).map { it.trim() }.filter { it.isNotEmpty() }.joinToString(" ")
    }

    private fun publishCarPlaybackError(message: String) {
        systemStateSignature = ""
        runCatching {
            mediaSession?.setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setState(PlaybackStateCompat.STATE_ERROR, musicPlayer.state.value.positionMs, 0f)
                    .setErrorMessage(message)
                    .build(),
            )
        }
    }

    private fun publishCarBrowseState(state: MusicPlayerState) {
        val signature = state.queue.joinToString(separator = "|") {
            "${it.videoId.orEmpty()}:${it.title}:${it.artist}"
        }
        if (signature == carBrowseQueueSignature) return
        carBrowseQueueSignature = signature
        notifyCarLibraryChanged(AndroidAutoMediaLibrary.QUEUE_ID)
        notifyChildrenChangedSafely(OriginOsMusicCard.LIST_CURRENT)
    }

    private fun notifyCarLibraryChanged(parentId: String) {
        runCatching {
            notifyChildrenChanged(AndroidAutoMediaLibrary.ROOT_ID)
            notifyChildrenChanged(parentId)
        }
    }

    /**
     * Stock Android music broadcasts (`com.android.music.metachanged` /
     * `playstatechanged` / `playbackcomplete`, plus the HTC doubles). KWGT,
     * Tasker, Zooper-style widgets and a long tail of headset/Bluetooth
     * helpers still listen for these alongside the modern MediaSession, and
     * several only list an app as a "media player" once they have seen one.
     * One ordered broadcast per track / play-state change; position ticks
     * are intentionally NOT rebroadcast.
     */
    private fun broadcastLegacyState(state: MusicPlayerState) {
        val track = state.current
        val playing = state.isPlaying
        val signature = "${track?.title}|${track?.artist}|${track?.album}|$playing"
        if (signature == legacyBroadcastSignature) return
        legacyBroadcastSignature = signature
        val title = track?.title.orEmpty()
        val artist = track?.artist.orEmpty()
        val album = track?.album.orEmpty()
        val extras = { intent: Intent ->
            intent
                .putExtra("track", title)
                .putExtra("artist", artist)
                .putExtra("album", album)
                .putExtra("playing", playing)
                .putExtra("isPlaying", playing)
                .putExtra("duration", state.durationMs)
                .putExtra("position", state.positionMs)
                .putExtra("package", packageName)
        }
        runCatching {
            if (track != null) {
                sendBroadcast(
                    extras(Intent("com.android.music.metachanged"))
                        .putExtra("id", state.currentIndex.toLong()),
                )
                sendBroadcast(extras(Intent("com.htc.music.metachanged")))
            } else {
                sendBroadcast(Intent("com.android.music.playbackcomplete"))
            }
            sendBroadcast(extras(Intent("com.android.music.playstatechanged")))
            sendBroadcast(extras(Intent("com.htc.music.playstatechanged")))
        }.onFailure { error ->
            android.util.Log.w("MusicPlaybackService", "Legacy player broadcast failed", error)
        }
    }

    private fun updateWakeLocks(state: MusicPlayerState) {
        val shouldHold = state.isPlaying || state.isBuffering
        if (shouldHold) {
            runCatching {
                if (playbackWakeLock?.isHeld == false) {
                    playbackWakeLock?.acquire()
                }
                if (playbackWifiLock?.isHeld == false) {
                    playbackWifiLock?.acquire()
                }
            }
        } else {
            runCatching {
                if (playbackWakeLock?.isHeld == true) playbackWakeLock?.release()
                if (playbackWifiLock?.isHeld == true) playbackWifiLock?.release()
            }
        }
    }

    private fun promoteForPlayback(): Boolean {
        if (isPlaybackForeground) return true
        // Browse-only Android Auto connections stay notification-free. A
        // started playback request promotes the already-bound service here.
        val notification = buildNotification(musicPlayer.state.value, artworkBitmap)
        val promoted = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        }.onFailure { firstError ->
            android.util.Log.w("MusicPlaybackService", "Rich startup notification rejected; retrying minimal", firstError)
        }.recoverCatching {
            val minimal = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, CHANNEL_ID)
            } else {
                @Suppress("DEPRECATION") Notification.Builder(this)
            }.setSmallIcon(R.drawable.ic_launcher_logo)
             .setContentTitle(musicPlayer.state.value.current?.title ?: "LastWave")
             .setContentText(musicPlayer.state.value.current?.artist ?: "Music player")
             .setOnlyAlertOnce(true)
             .build()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    minimal,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
                )
            } else {
                startForeground(NOTIFICATION_ID, minimal)
            }
        }.isSuccess
        isPlaybackForeground = promoted
        if (!promoted) {
            android.util.Log.w("MusicPlaybackService", "Foreground promotion refused by system")
        }
        return promoted
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Promote to foreground only when playback is actually active. A
        // pause/stop/no-op command must not force a media-playback FGS; when an
        // action such as PLAY starts playback the state collector promotes the
        // service on the isPlaying edge. If we do promote while active and the
        // system refuses, bail with START_NOT_STICKY as before.
        val state = musicPlayer.state.value
        if (state.isPlaying || state.isBuffering || intent?.action == null) {
            if (!promoteForPlayback()) return START_NOT_STICKY
        }
        when (intent?.action) {
            Intent.ACTION_MEDIA_BUTTON -> androidx.media.session.MediaButtonReceiver.handleIntent(mediaSession, intent)
            MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH -> playCarSearch(
                resolveCarSearchQuery(intent.getStringExtra(android.app.SearchManager.QUERY), intent.extras),
            )
            ACTION_PREVIOUS -> musicPlayer.previous()
            ACTION_TOGGLE -> musicPlayer.togglePlayPause()
            ACTION_NEXT -> musicPlayer.next()
            ACTION_SHUFFLE -> musicPlayer.toggleShuffle()
            ACTION_REPEAT -> musicPlayer.cycleRepeatMode()
            ACTION_STOP -> musicPlayer.stopAndClear()
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // With android:stopWithTask="true" in the Manifest, the system now
        // automatically stops this service when the task is removed from Recents.
        // If playback is active, the service is a foreground service (promoted
        // in onStartCommand) and will survive the task removal.
        // If nothing is playing, the service is not foreground and will be
        // stopped by the system, releasing wake/wifi locks via onDestroy().
        // We no longer need to manually call stopAndClear() here — the system
        // handles it correctly based on foreground state.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        runCatching { if (playbackWakeLock?.isHeld == true) playbackWakeLock?.release() }
        runCatching { if (playbackWifiLock?.isHeld == true) playbackWifiLock?.release() }
        // The service is the last thing standing in a playback-only session, so
        // this is the last chance to get buffered log records onto disk.
        com.lastwave.app.diagnostics.AppLog.flush()
        detectorJob?.cancel()
        artworkJob?.cancel()
        if (isPlaybackForeground) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
            else @Suppress("DEPRECATION") stopForeground(true)
            isPlaybackForeground = false
        }
        getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
        val releasedToken = platformSessionToken
        runCatching { mediaSession?.isActive = false }
        runCatching { mediaSession?.release() }
        castVolumeProvider = null
        // Let KWGT-style listeners clear their cached track on service death.
        runCatching { sendBroadcast(Intent("com.android.music.playbackcomplete")) }
        platformSessionToken = null
        ownController?.let { controller -> ActiveMediaSessionHolder.clear(controller) }
        ActiveMediaSessionHolder.clearToken(releasedToken)
        scope.cancel()
        super.onDestroy()
    }

    private fun cleanTrackMetadata(title: String, artist: String): CleanTrackMetadata {
        if (title == cleanedSourceTitle && artist == cleanedSourceArtist) return cleanedMetadata
        var cleanArtist = artist.trim()
            .replace(TOPIC_SUFFIX_REGEX, "")
            .replace(VEVO_SUFFIX_REGEX, "")
            .trim()
        if (com.lastwave.app.util.ArtistHelper.isPlayCountOrStat(cleanArtist)) {
            cleanArtist = ""
        }
        val cleanTitle = title.trim()
            .replace(TITLE_SUFFIX_REGEX, "")
            .trim()
        cleanedSourceTitle = title
        cleanedSourceArtist = artist
        return CleanTrackMetadata(
            cleanTitle.ifBlank { title },
            cleanArtist.ifBlank { artist },
        ).also { cleanedMetadata = it }
    }

    private fun detectTransition(state: MusicPlayerState) {
        val track = state.current ?: return
        val isEpisode = track.mediaType != com.lastwave.app.playback.MediaType.SONG ||
            !track.showId.isNullOrBlank() ||
            track.artist.equals("Podcast", ignoreCase = true)
        val (cleanTitle, cleanArtist) = cleanTrackMetadata(track.title, track.artist)
        val key = if (isEpisode) "podcast:${track.videoId.orEmpty()}" else "${cleanArtist.lowercase()}|${cleanTitle.lowercase()}"
        if (key == detectedKey) {
            if (state.isPlaying && key != nowPlayingAnnouncedKey) {
                announceNowPlaying(state)
            }
            return
        }

        // If previous track reached threshold before transition but wasn't submitted yet, submit now
        val prev = pendingPreviousTrack
        if (prev != null && !submissionAttempted && accumulatedMs >= 30_000L) {
            val (prevTitle, prevArtist) = cleanTrackMetadata(prev.title, prev.artist)
            val prevStartedAt = pendingPreviousStartedAt
            scope.launch(Dispatchers.IO) {
                runCatching {
                    scrobbleRepository.scrobble(
                        artist = prevArtist,
                        track = prevTitle,
                        album = prev.album,
                        timestampSec = prevStartedAt,
                    )
                }.onFailure { error ->
                    android.util.Log.e("MusicPlaybackService", "Deferred scrobble failed", error)
                }
            }
        }

        detectedKey = key
        pendingPreviousTrack = if (isEpisode) null else track
        pendingPreviousStartedAt = System.currentTimeMillis() / 1000
        nowPlayingAnnouncedKey = ""
        accumulatedMs = 0
        lastPositionMs = 0
        retryCount = 0
        startedAtEpochSec = System.currentTimeMillis() / 1000
        submissionAttempted = false

        if (state.isPlaying) {
            announceNowPlaying(state)
        }
    }

    private fun announceNowPlaying(state: MusicPlayerState) {
        val track = state.current ?: return
        if (track.mediaType != com.lastwave.app.playback.MediaType.SONG ||
            !track.showId.isNullOrBlank() ||
            track.artist.equals("Podcast", ignoreCase = true)
        ) return
        if (!state.isPlaying || !settings.submitNowPlaying) return
        // One announcement in flight at a time: during a rate-limit cooldown
        // each write can wait seconds on the shared write mutex — without this
        // guard the 1s detector loop would stack duplicate announcements that
        // all fire once the cooldown clears.
        if (nowPlayingInFlight) return
        val (cleanTitle, cleanArtist) = cleanTrackMetadata(track.title, track.artist)
        val key = "${cleanArtist.lowercase()}|${cleanTitle.lowercase()}"
        nowPlayingAnnouncedKey = key
        nowPlayingInFlight = true
        scope.launch(Dispatchers.IO) {
            try {
                val result = scrobbleRepository.updateNowPlaying(cleanArtist, cleanTitle, track.album)
                when {
                    result is ScrobbleRepository.Result.Success -> Unit
                    result is ScrobbleRepository.Result.Failed && result.retryable -> {
                        // Transient (rate limit / network): clear the announced key so
                        // the 1s detector loop re-attempts once the rate shield
                        // clears, instead of leaving Now Playing silently dead for
                        // the rest of the track.
                        if (nowPlayingAnnouncedKey == key) nowPlayingAnnouncedKey = ""
                    }
                    else -> Unit
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                // A throw here used to escape via try/finally with no catch
                // and (before the scope handler existed) kill the process.

                android.util.Log.e("MusicPlaybackService", "updateNowPlaying failed", e)
            } finally {
                nowPlayingInFlight = false
            }
        }
    }

    private fun startDetector() {
        detectorJob?.cancel()
        detectorJob = scope.launch {
            var wasPlaying = false
            while (true) {
                delay(1_000)
                val state = musicPlayer.state.value
                val track = state.current

                if (track == null) {
                    wasPlaying = false
                    continue
                }

                if (track.mediaType != com.lastwave.app.playback.MediaType.SONG ||
                    !track.showId.isNullOrBlank() ||
                    track.artist.equals("Podcast", ignoreCase = true)
                ) {
                    // Podcast episodes are never scrobbled. The detector still
                    // has to keep its position bookkeeping in sync so the
                    // timer below does not count stale seconds. The scrobble
                    // latch stays untouched: the next song must be able to
                    // scrobble normally.
                    wasPlaying = state.isPlaying
                    lastPositionMs = state.positionMs
                    accumulatedMs = 0L
                    continue
                }

                val (cleanTitle, cleanArtist) = cleanTrackMetadata(track.title, track.artist)
                val key = "${cleanArtist.lowercase()}|${cleanTitle.lowercase()}"

                // Announce Now Playing when transitioning to playing or if not yet announced
                if (state.isPlaying && (!wasPlaying || key != nowPlayingAnnouncedKey)) {
                    announceNowPlaying(state)
                }
                wasPlaying = state.isPlaying

                if (!state.isPlaying) continue

                // Check for track replay / restart
                if (state.positionMs in 1..4_000 && lastPositionMs > 20_000L && accumulatedMs > 15_000L) {
                    accumulatedMs = 0L
                    startedAtEpochSec = System.currentTimeMillis() / 1000
                    submissionAttempted = false
                    retryCount = 0
                    announceNowPlaying(state)
                }
                lastPositionMs = state.positionMs

                accumulatedMs += 1_000

                // Heartbeat to keep listener alive on global map (backend expires in 60s)
                if (accumulatedMs > 0 && accumulatedMs % 45_000L == 0L) {
                }

                if (submissionAttempted) continue

                // Calculate threshold with fallback for streaming tracks where duration is not yet reported
                val effectiveDuration = if (state.durationMs > 0) state.durationMs else 180_000L
                val percent = if (settings.scrobblePercent in 25..90) settings.scrobblePercent else 50
                val threshold = minOf(effectiveDuration * percent / 100, 4 * 60_000L).coerceAtLeast(30_000L)

                if (accumulatedMs < threshold) continue

                submissionAttempted = true
                scope.launch(Dispatchers.IO) {
                    runCatching {
                        when (val result = scrobbleRepository.scrobble(
                            artist = cleanArtist,
                            track = cleanTitle,
                            album = track.album,
                            timestampSec = startedAtEpochSec,
                        )) {
                            ScrobbleRepository.Result.Success -> {

                                // Re-announce now playing so Last.fm keeps active status during ongoing playback
                                if (musicPlayer.state.value.isPlaying) {
                                    scrobbleRepository.updateNowPlaying(cleanArtist, cleanTitle, track.album)
                                }
                            }
                            ScrobbleRepository.Result.NoSessionKey -> {

                            }
                            is ScrobbleRepository.Result.Failed -> {

                                // Allow up to 3 retries on network failure
                                if (retryCount < 3) {
                                    retryCount++
                                    submissionAttempted = false
                                }
                            }
                        }
                    }.onFailure { error ->
                        android.util.Log.e("MusicPlaybackService", "Scrobble submission crashed", error)
                    }
                }
            }
        }
    }

    private fun publishSystemState(state: MusicPlayerState) {
        val track = state.current
        // Transport-control target is cheap and must stay fresh every emission.
        val active = ActiveMediaSessionHolder.controller
        val otherAppIsPlaying = active?.packageName != packageName &&
            active?.playbackState?.state == PlatformPlaybackState.STATE_PLAYING
        if (track != null && (state.isPlaying || active == null || !otherAppIsPlaying)) {
            ActiveMediaSessionHolder.controller = ownController
        }

        // setMetadata/setPlaybackState are binder IPC into system_server. The
        // player state emits ~4x/second while playing; republishing on every
        // emission meant ~240 binder transactions/minute for identical data —
        // a constant main-thread tax that compounds into visible jank and
        // "app stopped responding" spells. PlaybackState carries position +
        // speed, so the system extrapolates between publishes; only actual
        // changes (track, duration, play/buffer state, artwork, or a seek
        // while paused) need to cross the binder.
        val playbackState = when {
            state.isBuffering -> PlaybackStateCompat.STATE_BUFFERING
            state.isPlaying -> PlaybackStateCompat.STATE_PLAYING
            track != null -> PlaybackStateCompat.STATE_PAUSED
            else -> PlaybackStateCompat.STATE_NONE
        }
        // Legacy stock-Android broadcasts KWGT/Tasker/Zooper-style widgets
        // still listen for. Sent even when the OEM media stack is broken
        // (session == null) so the fallback path keeps working.
        broadcastLegacyState(state)
        val session = mediaSession ?: return
        updateMediaSessionVolumeRouting(state.isCasting, state.appVolume)
        publishSessionQueue(session, state)
        val isLiked = track != null && trackLikeController.isLiked(track)
        val signature = buildString {
            append(track?.title).append('|')
            append(track?.artist).append('|')
            append(track?.album).append('|')
            append(state.durationMs).append('|')
            append(playbackState).append('|')
            append(state.shuffleEnabled).append('|')
            append(state.repeatMode).append('|')
            append(state.isCasting).append('|')
            append(state.appVolume).append('|')
            append(artworkUrl).append('|')
            append(artworkBitmap != null).append('|')
            append(isLiked)
            if (!state.isPlaying) append("|pos=").append(state.positionMs)
        }
        if (signature == systemStateSignature) return
        systemStateSignature = signature

        val artUri = artworkUrl ?: track?.artworkUrl.orEmpty()
        runCatching {
            session.setMetadata(
                MediaMetadataCompat.Builder()
                    // Unique per track: the OriginOS music card ignores a new
                    // track whose media id is the same as the one before.
                    .putString(
                        MediaMetadataCompat.METADATA_KEY_MEDIA_ID,
                        track?.let { OriginOsMusicCard.mediaIdOf(state.currentIndex, it) } ?: state.currentIndex.toString(),
                    )
                    .putString(MediaMetadataCompat.METADATA_KEY_TITLE, track?.title.orEmpty())
                    .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, track?.artist.orEmpty())
                    .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, track?.album.orEmpty())
                    .putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, artUri)
                    .putString(MediaMetadataCompat.METADATA_KEY_ART_URI, artUri)
                    .putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON_URI, artUri)
                    .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, state.durationMs)
                    .putRating(MediaMetadataCompat.METADATA_KEY_RATING, RatingCompat.newHeartRating(isLiked))
                    .putLong(OriginOsMusicCard.KEY_SUPPORT_EVENT, OriginOsMusicCard.SUPPORTED_EVENTS)
                    .putLong(
                        OriginOsMusicCard.KEY_LOOP_MODE,
                        OriginOsMusicCard.loopModeOf(state.shuffleEnabled, state.repeatMode).toLong(),
                    )
                    .apply {
                        val rawArt = artworkBitmap
                        val art = if (rawArt != null && (rawArt.width > 512 || rawArt.height > 512)) {
                            val maxDim = maxOf(rawArt.width, rawArt.height).toFloat()
                            val scale = 512f / maxDim
                            Bitmap.createScaledBitmap(rawArt, (rawArt.width * scale).toInt(), (rawArt.height * scale).toInt(), true)
                        } else rawArt
                        if (art != null) {
                            putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, art)
                            putBitmap(MediaMetadataCompat.METADATA_KEY_ART, art)
                            putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, art)
                        }
                    }
                    .build(),
            )
            session.setPlaybackState(
                PlaybackStateCompat.Builder()
                    .setActions(
                        PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                            PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SEEK_TO or
                            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM or PlaybackStateCompat.ACTION_STOP or
                            PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID or PlaybackStateCompat.ACTION_PLAY_FROM_SEARCH or
                            PlaybackStateCompat.ACTION_SET_SHUFFLE_MODE or PlaybackStateCompat.ACTION_SET_REPEAT_MODE or
                            PlaybackStateCompat.ACTION_SET_RATING,
                    )
                    .setActiveQueueItemId(state.currentIndex.toLong())
                    .setBufferedPosition(state.bufferedPositionMs)
                    .setState(playbackState, state.positionMs, if (state.isPlaying) state.speed else 0f)
                    .build(),
            )
            session.setShuffleMode(
                if (state.shuffleEnabled) PlaybackStateCompat.SHUFFLE_MODE_ALL
                else PlaybackStateCompat.SHUFFLE_MODE_NONE,
            )
            session.setRepeatMode(
                when (state.repeatMode) {
                    androidx.media3.common.Player.REPEAT_MODE_ONE -> PlaybackStateCompat.REPEAT_MODE_ONE
                    androidx.media3.common.Player.REPEAT_MODE_ALL -> PlaybackStateCompat.REPEAT_MODE_ALL
                    else -> PlaybackStateCompat.REPEAT_MODE_NONE
                },
            )
        }.onFailure { error ->
            // Binder IPC into a broken OEM media stack must not kill the
            // state collector that also drives notifications and widget.
            android.util.Log.w("MusicPlaybackService", "Media session publish failed", error)
        }
    }

    private var castVolumeProvider: VolumeProviderCompat? = null

    private fun updateMediaSessionVolumeRouting(isCasting: Boolean, appVolume: Float) {
        val session = mediaSession ?: return
        if (isCasting) {
            val maxVolume = 100
            val current = (appVolume * maxVolume).toInt().coerceIn(0, maxVolume)
            val existing = castVolumeProvider
            if (existing != null) {
                existing.currentVolume = current
            } else {
                val newProvider = object : VolumeProviderCompat(
                    VOLUME_CONTROL_ABSOLUTE,
                    maxVolume,
                    current,
                ) {
                    override fun onSetVolumeTo(volume: Int) {
                        val target = volume.toFloat() / maxVolume
                        musicPlayer.setAppVolume(target)
                    }

                    override fun onAdjustVolume(direction: Int) {
                        val step = when (direction) {
                            android.media.AudioManager.ADJUST_RAISE -> 0.05f
                            android.media.AudioManager.ADJUST_LOWER -> -0.05f
                            else -> 0f
                        }
                        if (step != 0f) {
                            val currentVol = musicPlayer.state.value.appVolume
                            musicPlayer.setAppVolume((currentVol + step).coerceIn(0f, 1f))
                        }
                    }
                }
                castVolumeProvider = newProvider
                session.setPlaybackToRemote(newProvider)
            }
        } else {
            if (castVolumeProvider != null) {
                castVolumeProvider = null
                session.setPlaybackToLocal(android.media.AudioManager.STREAM_MUSIC)
            }
        }
    }

    private fun publishSessionQueue(session: MediaSessionCompat, state: MusicPlayerState) {
        val signature = state.queue.joinToString(separator = "|") {
            "${it.videoId.orEmpty()}:${it.title}:${it.artist}"
        }
        if (signature == sessionQueueSignature) return
        sessionQueueSignature = signature
        val start = (state.currentIndex - MAX_CAR_QUEUE_BEFORE_CURRENT).coerceAtLeast(0)
        val end = (start + MAX_CAR_QUEUE_ITEMS).coerceAtMost(state.queue.size)
        val queue = (start until end).map { index ->
            val track = state.queue[index]
            MediaSessionCompat.QueueItem(
                MediaDescriptionCompat.Builder()
                    .setMediaId("queue:$index")
                    .setTitle(track.title)
                    .setSubtitle(track.artist)
                    .setDescription(track.album)
                    .build(),
                index.toLong(),
            )
        }
        runCatching {
            session.setQueue(queue)
            session.setQueueTitle(state.sourceLabel)
        }.onFailure { error ->
            android.util.Log.w("MusicPlaybackService", "Media session queue publish failed", error)
        }
    }

    private fun publishWidget(state: MusicPlayerState) {
        val track = state.current ?: return
        val active = ActiveMediaSessionHolder.controller
        val otherAppIsPlaying = active?.packageName != packageName &&
            active?.playbackState?.state == PlatformPlaybackState.STATE_PLAYING
        if (!state.isPlaying && otherAppIsPlaying) return
        val signature = "${track.title}|${track.artist}|${state.isPlaying}|$artworkUrl|${artworkBitmap != null}"
        if (signature == widgetSignature) return
        widgetSignature = signature
        scope.launch(Dispatchers.IO) {
            WidgetUpdater.publish(
                context = this@MusicPlaybackService,
                title = track.title,
                artist = track.artist,
                album = track.album,
                sourceApp = getString(R.string.app_name),
                sourcePackage = packageName,
                art = artworkBitmap,
                isPlaying = state.isPlaying,
            )
        }
    }

    private fun publishNotification(state: MusicPlayerState, force: Boolean = false) {
        val track = state.current
        if (track == null) {
            notificationSignature = ""
            if (isPlaybackForeground) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
                else @Suppress("DEPRECATION") stopForeground(true)
                isPlaybackForeground = false
            }
            getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
            return
        }
        // A loaded track keeps the media-playback foreground service alive even
        // while paused. Demoting to an ordinary background service on pause is
        // what made the whole session vanish on aggressive OEMs (HyperOS/MIUI,
        // ColorOS, One UI) the moment another app came to the front: the frozen
        // process takes the media notification and the MediaSession with it, so
        // there is nothing left to resume from. The FGS costs nothing while
        // paused — updateWakeLocks() has already released the wake/wifi locks —
        // and the system keeps the notification that carries the transport
        // controls. Only stopAndClear() (track == null, handled above) leaves
        // the foreground state.
        if (!isPlaybackForeground) {
            if (!promoteForPlayback()) return
        }
        val signature = "${track.title}|${track.artist}|${track.album}|${state.isPlaying}|${state.isBuffering}|${state.shuffleEnabled}|${state.repeatMode}|$artworkUrl|${artworkBitmap != null}"
        if (!force && signature == notificationSignature) return
        val success = runCatching {
            getSystemService(NotificationManager::class.java)
                ?.notify(NOTIFICATION_ID, buildNotification(state, artworkBitmap))
            true
        }.onFailure { error ->
            // Some OEMs throw from notify() for transient binder failures;
            // clearing signature allows subsequent state emissions to retry.
            android.util.Log.w("MusicPlaybackService", "Notification publish failed", error)
        }.getOrDefault(false)

        if (success) {
            notificationSignature = signature
        } else {
            notificationSignature = ""
        }
    }

    private fun requestArtwork(track: PlayableTrack?) {
        if (track == null) {
            artworkRequestKey = ""
            artworkUrl = null
            artworkBitmap = null
            artworkJob?.cancel()
            return
        }

        // The player state emits ~4x/second; without this guard every emission
        // re-launched an artwork resolution job for the same track.
        val requestKey = "${track.title}|${track.artist}|${track.artworkUrl.orEmpty()}"
        if (requestKey == artworkRequestKey) return
        artworkRequestKey = requestKey

        // Track has changed: immediately clear previous track's artwork
        // so the notification bar never displays the old song's cover art
        artworkBitmap = null
        artworkUrl = null
        artworkJob?.cancel()

        val key = com.lastwave.app.data.artwork.ArtworkNormalizer.cacheKey(track.title, track.artist)
        val cached = artworkRepository.resolved.value[key]?.takeIf(String::isNotBlank)
        if (cached != null) {
            fetchArtwork(cached)
            return
        }

        // Show immediate upscaled placeholder while high-res artwork resolves
        val placeholder = com.lastwave.app.data.artwork.ArtworkNormalizer.upscaleYoutubeArtwork(track.artworkUrl)?.takeIf(String::isNotBlank)
        if (placeholder != null) {
            fetchArtwork(placeholder)
        }

        // Resolve high-resolution master artwork after this track is audible.
        // Starting Tidal/Deezer/iTunes on the tap shares connections with the
        // stream extract and stretches the gap before the next song.
        scope.launch(Dispatchers.IO) {
            withTimeoutOrNull(8_000L) {
                musicPlayer.state.drop(1).first { state ->
                    val same = track.videoId.isNullOrBlank() || state.current?.videoId == track.videoId
                    same && state.isPlaying && !state.isBuffering && state.error == null
                }
            }
            if (artworkRequestKey != requestKey) {
                MetadataLog.skipped("artwork", track.videoId)
                return@launch
            }
            MetadataLog.delayed("artwork", track.videoId)
            delay(MetadataLog.SETTLE_MS)
            if (artworkRequestKey != requestKey) {
                MetadataLog.skipped("artwork", track.videoId)
                return@launch
            }
            MetadataLog.started("artwork", track.videoId)
            artworkRepository.resolve(track.title, track.artist)
            val resolved = artworkRepository.resolved.value[key]?.takeIf(String::isNotBlank)
            if (resolved != null && resolved != artworkUrl) {
                withContext(Dispatchers.Main) {
                    if (artworkRequestKey == requestKey) {
                        fetchArtwork(resolved)
                    }
                }
            }
        }
    }

    private fun fetchArtwork(url: String) {
        val cleanUrl = url.trim()
        if (cleanUrl.isBlank()) return
        if (cleanUrl == artworkUrl && artworkBitmap != null) return
        artworkUrl = cleanUrl
        artworkJob?.cancel()

        // Immediate memory cache lookup for zero-latency widget update
        runCatching {
            val cached = imageLoader.memoryCache?.get(coil.memory.MemoryCache.Key(cleanUrl))?.bitmap
            if (cached != null && !cached.isRecycled) {
                artworkBitmap = cached
                widgetSignature = ""
                publishWidget(musicPlayer.state.value)
            }
        }

        artworkJob = scope.launch {
            val expectedUrl = cleanUrl
            val result = kotlinx.coroutines.withContext(Dispatchers.IO) {
                imageLoader.execute(
                    ImageRequest.Builder(this@MusicPlaybackService)
                        .data(expectedUrl)
                        .size(512)
                        .allowHardware(false)
                        .build(),
                )
            }
            if (expectedUrl != artworkUrl) return@launch
            artworkBitmap = (result as? SuccessResult)?.drawable?.toBitmap()
            val state = musicPlayer.state.value
            publishSystemState(state)
            publishNotification(state, force = true)
            widgetSignature = ""
            publishWidget(state)
        }
    }


    private fun openAppPendingIntent(): PendingIntent = PendingIntent.getActivity(
        this,
        0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun useSystemMediaStyle(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU || isChineseOemSkin()

    /** Heavily-skinned ROMs whose lockscreen/panel only honor standard MediaStyle. */
    private fun isChineseOemSkin(): Boolean {
        val m = Build.MANUFACTURER.lowercase()
        return m.contains("vivo") || m.contains("iqoo") ||
            m.contains("oppo") || m.contains("oneplus") || m.contains("realme") ||
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") ||
            m.contains("huawei") || m.contains("honor") ||
            m.contains("nubia") || m.contains("zte") ||
            m.contains("tecno") || m.contains("infinix") || m.contains("itel") ||
            m.contains("meizu")
    }

    private fun buildNotification(state: MusicPlayerState, art: Bitmap?): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }

        // System-rendered MediaStyle path. Used on Android 13+ (SystemUI /
        // Samsung One UI host the player natively and reject custom
        // RemoteViews) and on Chinese-OEM skins (Vivo/OriginOS, OPPO/ColorOS,
        // OnePlus, Realme, Xiaomi/HyperOS, Huawei/EMUI, Honor, …): their
        // lockscreen + control-center media cards never render third-party
        // custom RemoteViews — they draw their own card from the MediaSession,
        // so the material custom views would mean no controls at all there.
        // Everywhere else (Pixels, Motorola, …) the custom views survive.
        if (useSystemMediaStyle()) {
            val mediaStyle = Notification.MediaStyle()
                .setShowActionsInCompactView(0, 1, 2)
            platformSessionToken?.let { mediaStyle.setMediaSession(it) }

            val repeatIcon = when (state.repeatMode) {
                androidx.media3.common.Player.REPEAT_MODE_ONE -> R.drawable.ic_widget_repeat_one
                else -> R.drawable.ic_widget_repeat
            }
            val repeatLabel = when (state.repeatMode) {
                androidx.media3.common.Player.REPEAT_MODE_ONE -> "Repeat one"
                androidx.media3.common.Player.REPEAT_MODE_ALL -> "Repeat all"
                else -> "Repeat off"
            }

            // Hosts that can't render custom views (cars, watches, DeX text
            // rows) show these titles verbatim — "Play or pause" looked broken,
            // so the play action always reads the actual current state.
            val playPauseLabel = if (state.isPlaying) "Pause" else "Play"
            return builder
                .setSmallIcon(R.drawable.ic_launcher_logo)
                .setContentTitle(state.current?.title ?: "LastWave")
                .setContentText(state.current?.artist ?: "Music player")
                .setSubText(state.current?.album)
                .setContentIntent(openAppPendingIntent())
                .setLargeIcon(scaledBitmap(art, 384))
                .setOnlyAlertOnce(true)
                .setOngoing(state.isPlaying)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setColor(notificationPalette.primary)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setStyle(mediaStyle)
                .addAction(Notification.Action.Builder(R.drawable.ic_widget_skip_previous, "Previous", serviceAction(ACTION_PREVIOUS, 1)).build())
                .addAction(Notification.Action.Builder(if (state.isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play, playPauseLabel, serviceAction(ACTION_TOGGLE, 2)).build())
                .addAction(Notification.Action.Builder(R.drawable.ic_widget_skip_next, "Next", serviceAction(ACTION_NEXT, 3)).build())
                .addAction(Notification.Action.Builder(R.drawable.ic_widget_shuffle, if (state.shuffleEnabled) "Shuffle on" else "Shuffle off", serviceAction(ACTION_SHUFFLE, 5)).build())
                .addAction(Notification.Action.Builder(repeatIcon, repeatLabel, serviceAction(ACTION_REPEAT, 6)).build())
                .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", serviceAction(ACTION_STOP, 4)).build())
                .setColorized(true)
                .apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
                    }
                }
                .build()
        }

        val compact = notificationRemoteViews(
            layout = R.layout.notification_player_compact,
            widthDp = 520,
            heightDp = 72,
            state = state,
            art = art,
            expanded = false,
        )
        val expanded = notificationRemoteViews(
            layout = R.layout.notification_player_expanded,
            widthDp = 520,
            heightDp = EXPANDED_HEIGHT_DP,
            state = state,
            art = art,
            expanded = true,
        )
        // On Android 10 and below (One UI 2.x especially), attaching a
        // MediaSession to DecoratedMediaCustomViewStyle causes SystemUI's
        // older media-notification renderer to draw its own full media
        // chrome as a second layer on top of our custom RemoteViews,
        // instead of just framing it — producing two overlapping players.
        // Our compact/expanded RemoteViews already draw everything (art,
        // title, artist, transport buttons), so the system's own media
        // decoration is redundant; drop just the session tag on affected
        // versions. Lock screen, Bluetooth, Android Auto, and the in-app
        // widget are unaffected — they all read from `mediaSession`
        // directly, never from this notification Style object.
        val style = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Notification.DecoratedMediaCustomViewStyle()
                .setShowActionsInCompactView(0, 1, 2)
                .also { s -> platformSessionToken?.let(s::setMediaSession) }
        } else {
            Notification.DecoratedCustomViewStyle()
        }

        return builder
            .setSmallIcon(R.drawable.ic_launcher_logo)
            .setContentTitle(state.current?.title ?: "LastWave")
            .setContentText(state.current?.artist ?: "Music player")
            .setSubText(state.current?.album)
            .setContentIntent(openAppPendingIntent())
            .setLargeIcon(scaledBitmap(art, 384))
            .setOnlyAlertOnce(true)
            .setOngoing(state.isPlaying)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setColor(notificationPalette.primary)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setStyle(style)
            .setCustomContentView(compact)
            .setCustomBigContentView(expanded)
            .setCustomHeadsUpContentView(compact)
            .addAction(Notification.Action.Builder(R.drawable.ic_widget_skip_previous, "Previous", serviceAction(ACTION_PREVIOUS, 1)).build())
            .addAction(Notification.Action.Builder(if (state.isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play, if (state.isPlaying) "Pause" else "Play", serviceAction(ACTION_TOGGLE, 2)).build())
            .addAction(Notification.Action.Builder(R.drawable.ic_widget_skip_next, "Next", serviceAction(ACTION_NEXT, 3)).build())
            .addAction(Notification.Action.Builder(R.drawable.ic_widget_shuffle, if (state.shuffleEnabled) "Shuffle on" else "Shuffle off", serviceAction(ACTION_SHUFFLE, 5)).build())
            .addAction(
                Notification.Action.Builder(
                    when (state.repeatMode) {
                        androidx.media3.common.Player.REPEAT_MODE_ONE -> R.drawable.ic_widget_repeat_one
                        else -> R.drawable.ic_widget_repeat
                    },
                    when (state.repeatMode) {
                        androidx.media3.common.Player.REPEAT_MODE_ONE -> "Repeat one"
                        androidx.media3.common.Player.REPEAT_MODE_ALL -> "Repeat all"
                        else -> "Repeat off"
                    },
                    serviceAction(ACTION_REPEAT, 6),
                ).build(),
            )
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Stop", serviceAction(ACTION_STOP, 4)).build())
            .apply {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) setColorized(true)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
                }
            }
            .build()
    }

    private fun notificationRemoteViews(
        layout: Int,
        widthDp: Int,
        heightDp: Int,
        state: MusicPlayerState,
        art: Bitmap?,
        expanded: Boolean,
    ): RemoteViews = RemoteViews(packageName, layout).apply {
        val palette = notificationPalette
        setImageViewBitmap(R.id.notification_background, glassBackground(widthDp, heightDp, palette))
        // Expanded art is shown at 96dp (288px @3x); compact at 54dp where
        // 192px is already sharp. Two sizes keep the Binder parcel small.
        if (art != null) setImageViewBitmap(R.id.notification_artwork, scaledBitmap(art, if (expanded) 288 else 192))
        else setImageViewResource(R.id.notification_artwork, R.mipmap.ic_launcher)
        setTextViewText(R.id.notification_title, state.current?.title ?: "LastWave")
        setTextViewText(R.id.notification_artist, state.current?.artist ?: "Music player")
        setTextColor(R.id.notification_title, palette.onSurface)
        setTextColor(R.id.notification_artist, palette.onSurfaceVariant)
        setImageViewResource(
            R.id.notification_play_pause,
            if (state.isPlaying) R.drawable.ic_widget_pause else R.drawable.ic_widget_play,
        )
        setImageViewResource(
            R.id.notification_previous,
            R.drawable.ic_widget_skip_previous,
        )
        setImageViewResource(
            R.id.notification_next,
            R.drawable.ic_widget_skip_next,
        )
        // Shuffle/repeat only exist in the expanded layout; the compact row
        // is the prev/play/next transport cluster.
        if (expanded) {
            setImageViewResource(
                R.id.notification_shuffle,
                R.drawable.ic_widget_shuffle,
            )
            setImageViewResource(
                R.id.notification_repeat,
                if (state.repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE) R.drawable.ic_widget_repeat_one else R.drawable.ic_widget_repeat,
            )
            setInt(
                R.id.notification_shuffle,
                "setColorFilter",
                if (state.shuffleEnabled) palette.primary else palette.onSurface,
            )
            setInt(
                R.id.notification_repeat,
                "setColorFilter",
                if (state.repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) palette.primary else palette.onSurface,
            )
            setOnClickPendingIntent(R.id.notification_shuffle, serviceAction(ACTION_SHUFFLE, 5))
            setOnClickPendingIntent(R.id.notification_repeat, serviceAction(ACTION_REPEAT, 6))
        }
        setInt(R.id.notification_previous, "setColorFilter", palette.onSurface)
        setInt(R.id.notification_next, "setColorFilter", palette.onSurface)
        setInt(R.id.notification_play_surface, "setColorFilter", palette.primary)
        setInt(R.id.notification_play_pause, "setColorFilter", palette.onPrimary)
        setOnClickPendingIntent(R.id.notification_root, openAppPendingIntent())
        setOnClickPendingIntent(R.id.notification_previous, serviceAction(ACTION_PREVIOUS, 1))
        setOnClickPendingIntent(R.id.notification_play_pause, serviceAction(ACTION_TOGGLE, 2))
        setOnClickPendingIntent(R.id.notification_next, serviceAction(ACTION_NEXT, 3))
        if (expanded) {
            setTextColor(R.id.notification_brand, palette.primary)
            setTextViewText(R.id.notification_album, state.current?.album.orEmpty())
            setTextColor(R.id.notification_album, palette.onSurfaceVariant)
            setViewVisibility(
                R.id.notification_album,
                if (state.current?.album.isNullOrBlank()) View.GONE else View.VISIBLE,
            )
        }
    }

    private fun glassBackground(widthDp: Int, heightDp: Int, palette: NotificationPalette): Bitmap {
        // Keep these bitmaps intentionally pixel-sized, not density-scaled:
        // RemoteViews crosses Binder and oversized bitmaps can exceed its
        // transaction limit. The ImageView stretches this small gradient.
        val width = widthDp.coerceAtLeast(1)
        val height = heightDp.coerceAtLeast(1)
        val radius = 30f
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val bounds = RectF(0f, 0f, width.toFloat(), height.toFloat())
        // Deeper accent blend than before: the old 0.20/0.13 wash read as
        // flat grey on wide hosts (DeX, cars) with white text on top.
        val start = ColorUtils.setAlphaComponent(
            ColorUtils.blendARGB(palette.surface, palette.primary, 0.34f),
            242,
        )
        val mid = ColorUtils.setAlphaComponent(
            ColorUtils.blendARGB(palette.surface, palette.primary, 0.18f),
            236,
        )
        val end = ColorUtils.setAlphaComponent(
            ColorUtils.blendARGB(palette.surface, palette.tertiary, 0.26f),
            230,
        )
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(start, mid, end), floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP,
            )
        }
        canvas.drawRoundRect(bounds, radius, radius, fill)
        // Crisp edge definition: hairline top highlight + soft inner shadow
        // so the card doesn't melt into the shade background when stretched.
        val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = ColorUtils.setAlphaComponent(palette.onSurface, 52)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        canvas.drawRoundRect(
            RectF(1f, 1f, width - 1f, height - 1f),
            radius,
            radius,
            highlight,
        )
        return bitmap
    }

    private fun scaledBitmap(source: Bitmap?, maxEdge: Int): Bitmap? {
        source ?: return null
        val largest = maxOf(source.width, source.height)
        if (largest <= maxEdge) return source
        val scale = maxEdge.toFloat() / largest
        return Bitmap.createScaledBitmap(
            source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1),
            true,
        )
    }

    private fun serviceAction(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this,
        requestCode,
        Intent(this, MusicPlaybackService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        runCatching {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            // Lockscreen media cards on Vivo/Chinese ROMs are suppressed on
            // LOW importance. Importance is immutable once created, so v3
            // (DEFAULT without sound/vibration) replaces earlier channels outright.
            runCatching { nm.deleteNotificationChannel(LEGACY_CHANNEL_ID) }
            runCatching { nm.deleteNotificationChannel(LEGACY_CHANNEL_ID_V1) }
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Music playback", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Native LastWave playback controls"
                    setShowBadge(false)
                    setSound(null, null)
                    enableVibration(false)
                },
            )
        }.onFailure { error ->
            android.util.Log.w("MusicPlaybackService", "Notification channel unavailable", error)
        }
    }

    private companion object {
        // Expanded RemoteViews content needs ~117dp (brand + title + artist +
        // album + 44dp controls + margins); 128dp clipped the transport row
        // whenever the album line was visible. 152dp leaves breathing room.
        const val EXPANDED_HEIGHT_DP = 152
        const val CONTENT_STYLE_BROWSABLE_HINT = "android.media.browse.CONTENT_STYLE_BROWSABLE_HINT"
        const val CONTENT_STYLE_PLAYABLE_HINT = "android.media.browse.CONTENT_STYLE_PLAYABLE_HINT"
        const val CONTENT_STYLE_LIST = 1
        const val MAX_CAR_QUEUE_ITEMS = 100
        const val MAX_CAR_QUEUE_BEFORE_CURRENT = 50
        const val CHANNEL_ID = "lastwave_playback_v3"
        const val LEGACY_CHANNEL_ID = "lastwave_playback_v2"
        const val LEGACY_CHANNEL_ID_V1 = "lastwave_playback"
        const val NOTIFICATION_ID = 4102
        const val ACTION_PREVIOUS = "com.lastwave.app.playback.PREVIOUS"
        const val ACTION_TOGGLE = "com.lastwave.app.playback.TOGGLE"
        const val ACTION_NEXT = "com.lastwave.app.playback.NEXT"
        const val ACTION_SHUFFLE = "com.lastwave.app.playback.SHUFFLE"
        const val ACTION_REPEAT = "com.lastwave.app.playback.REPEAT"
        const val ACTION_STOP = "com.lastwave.app.playback.STOP"
    }
}

private data class NotificationPalette(
    val primary: Int,
    val onPrimary: Int,
    val surface: Int,
    val onSurface: Int,
    val onSurfaceVariant: Int,
    val tertiary: Int,
) {
    companion object {
        fun from(scheme: androidx.compose.material3.ColorScheme) = NotificationPalette(
            primary = scheme.primary.toArgb(),
            onPrimary = scheme.onPrimary.toArgb(),
            surface = scheme.surfaceContainerHigh.toArgb(),
            onSurface = scheme.onSurface.toArgb(),
            onSurfaceVariant = scheme.onSurfaceVariant.toArgb(),
            tertiary = scheme.tertiary.toArgb(),
        )

        fun default() = NotificationPalette(
            primary = 0xFFFFB4AB.toInt(),
            onPrimary = 0xFF690005.toInt(),
            surface = 0xFF211A1A.toInt(),
            onSurface = 0xFFEDE0DE.toInt(),
            onSurfaceVariant = 0xFFD8C2BF.toInt(),
            tertiary = 0xFFE7C089.toInt(),
        )
    }
}
