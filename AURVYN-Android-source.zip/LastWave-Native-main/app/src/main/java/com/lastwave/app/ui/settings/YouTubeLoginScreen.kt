package com.lastwave.app.ui.settings

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.lastwave.app.R
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.lastwave.app.ui.common.ExpressiveHeader
import com.lastwave.app.ui.common.adaptiveContentWidth

/**
 * Native-feeling YouTube Music sign-in: a WebView loads Google's own sign-in
 * flow (no embedded passwords, no OAuth project), and once music.youtube.com
 * has session cookies the app captures them via the system CookieManager —
 * exactly how the browser itself persists a logged-in session. No cookie is
 * ever sent anywhere except back to YouTube's own endpoints.
 */
@Composable
fun YouTubeLoginScreen(
    onBack: () -> Unit,
    onConnected: () -> Unit,
    viewModel: YouTubeLoginViewModel = hiltViewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var loadProgressVisible by remember { mutableStateOf(true) }
    var webViewError by remember { mutableStateOf<String?>(null) }
    var showCookieDialog by remember { mutableStateOf(false) }
    var activeWebView by remember { mutableStateOf<WebView?>(null) }

    LaunchedEffect(Unit) {
        runCatching {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
            android.webkit.WebStorage.getInstance().deleteAllData()
        }
    }

    LaunchedEffect(state.connectedName, state.verifying, activeWebView) {
        if (state.connectedName != null || state.verifying) return@LaunchedEffect
        while (true) {
            val currentUrl = activeWebView?.url
            val isAtTarget = currentUrl?.contains("music.youtube.com") == true
            if (isAtTarget) {
                val cookies = readYouTubeCookies()
                if (hasSessionTokens(cookies)) {
                    val current = viewModel.uiState.value
                    if (!current.verifying && current.connectedName == null) {
                        viewModel.attemptConnect(cookies)
                    }
                    break
                }
            }
            kotlinx.coroutines.delay(1_200L)
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .adaptiveContentWidth(maxWidth = 760.dp),
        ) {
        ExpressiveHeader(
            title = "Connect YouTube Music",
            subtitle = "Sign in with your Google account",
            onBack = onBack,
            actions = {
                FilledTonalIconButton(
                    onClick = { showCookieDialog = true },
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerHighest,
                    ),
                ) {
                    Icon(
                        Icons.Filled.Key,
                        contentDescription = stringResource(R.string.settings_cookie_login),
                    )
                }
            },
        )

        Box(Modifier.weight(1f)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    var createdWebView: WebView? = null
                    try {
                        WebView(ctx).also {
                            createdWebView = it
                            activeWebView = it
                        }.apply {
                        @SuppressLint("SetJavaScriptEnabled")
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.databaseEnabled = true
                        clearCache(true)
                        clearHistory()
                        clearFormData()
                        // Google blocks the default WebView user agent on
                        // accounts.google.com ("may not be secure"). Stripping
                        // embedded WebView markers ("; wv" and "Version/4.0" / "Version/X.X")
                        // preserves the device's real Chrome engine version,
                        // avoiding client-hint and security fingerprint mismatches on ColorOS/Realme UI.
                        val defaultUa = settings.userAgentString
                        val cleanUa = if (!defaultUa.isNullOrBlank()) {
                            defaultUa.replace("; wv", "")
                                .replace("Version/4.0 ", "")
                                .replace("Version/4.0", "")
                                .replace(Regex("Version/\\d+\\.\\d+\\s*"), "")
                        } else {
                            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                        }
                        settings.userAgentString = cleanUa
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                        webViewClient = object : WebViewClient() {
                            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                super.doUpdateVisitedHistory(view, url, isReload)
                                val current = viewModel.uiState.value
                                if (current.verifying || current.connectedName != null) return
                                CookieManager.getInstance().flush()
                                val cookies = readYouTubeCookies()
                                if (hasSessionTokens(cookies)) {
                                    viewModel.attemptConnect(cookies)
                                }
                            }

                            override fun onPageCommitVisible(view: WebView?, url: String?) {
                                super.onPageCommitVisible(view, url)
                                CookieManager.getInstance().flush()
                                val current = viewModel.uiState.value
                                if (current.verifying || current.connectedName != null) return
                                val cookies = readYouTubeCookies()
                                if (hasSessionTokens(cookies)) {
                                    viewModel.attemptConnect(cookies)
                                }
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                loadProgressVisible = false
                                CookieManager.getInstance().flush()
                                val current = viewModel.uiState.value
                                if (current.verifying || current.connectedName != null) return
                                val cookies = readYouTubeCookies()
                                if (hasSessionTokens(cookies)) {
                                    viewModel.attemptConnect(cookies)
                                }
                            }
                        }
                            loadUrl(LOGIN_URL)
                        }
                    } catch (error: Exception) {
                        runCatching { createdWebView?.destroy() }
                        activeWebView = null
                        loadProgressVisible = false
                        webViewError = "Android System WebView is unavailable. Install or enable a WebView provider to connect YouTube Music."
                        android.widget.FrameLayout(ctx)
                    } catch (error: LinkageError) {
                        runCatching { createdWebView?.destroy() }
                        loadProgressVisible = false
                        webViewError = "This ROM's WebView implementation is incompatible. YouTube Music sign-in is disabled safely."
                        android.widget.FrameLayout(ctx)
                    }
                },
            )

            if (webViewError != null) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.align(Alignment.Center).padding(24.dp),
                ) {
                    Text(
                        webViewError.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(20.dp),
                    )
                }
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = state.connectedName != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
            ) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                ) {
                    Column(
                        modifier = Modifier.padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(56.dp),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(32.dp),
                                )
                            }
                        }
                        Text(
                            "Connected",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                        Text(
                            state.connectedName.orEmpty(),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                        )
                        Button(onClick = onConnected, shape = CircleShape) {
                            Text(stringResource(R.string.ytlogin_continue))
                        }
                    }
                }
            }

            if (loadProgressVisible && state.connectedName == null) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
                )
            }
        }

        // Bottom helper bar — native pattern for embedded web flows.
        Surface(color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.CloudSync,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "LastWave never sees your password — sign-in happens entirely inside Google's page.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (state.errorMessage != null) {
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            state.errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    OutlinedButton(
                        onClick = { showCookieDialog = true },
                        enabled = !state.verifying && state.connectedName == null,
                        shape = CircleShape,
                        modifier = Modifier.weight(1f).height(46.dp),
                    ) {
                        Icon(
                            Icons.Filled.Key,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Cookie Login",
                            maxLines = 1,
                        )
                    }
                    Button(
                        onClick = {
                            viewModel.attemptConnect(readYouTubeCookies())
                        },
                        enabled = webViewError == null && !state.verifying && state.connectedName == null,
                        shape = CircleShape,
                        modifier = Modifier.weight(1.2f).height(46.dp),
                    ) {
                        if (state.verifying) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.ytlogin_verifying))
                        } else {
                            Text(stringResource(R.string.ytlogin_signed_in))
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "After signing in or connecting cookies you'll be returned here automatically.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                )
            }
        }
    }
    }

    if (showCookieDialog) {
        CookieLoginDialog(
            onDismiss = { showCookieDialog = false },
            onConnect = { cookies ->
                showCookieDialog = false
                viewModel.attemptCookieConnect(cookies)
            },
            isConnecting = state.verifying,
        )
    }
}

private const val LOGIN_URL =
    "https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3Dhttps%253A%252F%252Fmusic.youtube.com%252F&hl=en"

private fun hasSessionTokens(cookies: String?): Boolean {
    if (cookies.isNullOrBlank()) return false
    val hasSapisid = cookies.contains("SAPISID=") || cookies.contains("__Secure-3PAPISID=")
    val hasSid = cookies.contains("SID=") || cookies.contains("__Secure-3PSID=")
    return hasSapisid && hasSid
}

private fun readYouTubeCookies(): String? = try {
    val cm = CookieManager.getInstance()
    cm.flush()
    val domains = listOf(
        "https://music.youtube.com",
        "https://www.youtube.com",
        "https://accounts.google.com",
        "https://youtube.com",
    )
    val cookieMap = mutableMapOf<String, String>()
    for (domain in domains) {
        val raw = cm.getCookie(domain) ?: continue
        for (part in raw.split(';')) {
            val idx = part.indexOf('=')
            if (idx > 0) {
                val name = part.substring(0, idx).trim()
                val value = part.substring(idx + 1).trim()
                if (name.isNotBlank() && value.isNotBlank()) {
                    cookieMap[name] = value
                }
            }
        }
    }
    if (cookieMap.isEmpty()) null else cookieMap.entries.joinToString("; ") { "${it.key}=${it.value}" }
} catch (error: Exception) {
    null
} catch (error: LinkageError) {
    null
}
